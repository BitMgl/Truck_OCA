#include <ros/ros.h>
#include <iostream>
#include <map>
#include <string>

#include "matplotlibcpp.h"
#include "em_planner.h"
#include "sce1.h"
#include "sce2.h"
#include "sce3.h"
#include "sce4.h"
#include <thread>

#include "em_planner_ros/PlanningResult.h"
#include "em_planner_ros/TrajectoryPoint.h"
#include "em_planner_ros/ObstacleList.h"
#include "em_planner_ros/Obstacle.h"
#include "em_planner_ros/Localization.h"

namespace plt = matplotlibcpp;

const double ego_v  = 5.0; // 应为Enviroment发布

class PlannerNode {
public:
  PlannerNode() ; // 构造函数，里头初始化publisher
  void run();       // 原 main 函数的主要逻辑，后面我添加了publisher
  void referenceLineCallback(const em_planner_ros::PlanningResult::ConstPtr& msg);
  void obstacleCallback(const em_planner_ros::ObstacleList::ConstPtr& msg);
  void localizationCallback(const em_planner_ros::Localization::ConstPtr& msg);
  std::vector<TrajectoryPoint> reference_line_;
  ObstacleList obs_;
  TrajectoryPoint current_pose_;

private:
  ros::NodeHandle nh_;
  ros::Publisher qp_result_pub_;
  ros::Publisher qp_speed_pub_;
  ros::Publisher dp_result_pub_;

  ros::Subscriber refline_sub_;
  ros::Subscriber obstacles_sub_; //需要加什么新的subscriber直接在这个后面加。
  ros::Subscriber localization_sub_;
  



  void rotate(std::vector<double>& ego_x, std::vector<double>& ego_y, double x,
              double y, double x_center, double y_center, double theta) {
    double rad = theta;  // 弧度
    double d = 2.236;    // 计算点之间的距离
    double alpha =
        std::atan2(y - y_center, x - x_center);  // 计算点 a 相对于点 b 的方位角
    alpha += rad;                                // 增加角度
    x = x_center + d * std::cos(alpha);  // 更新点 a 的 x 坐标
    y = y_center + d * std::sin(alpha);  // 更新点 a 的 y 坐标
    ego_x.push_back(x);
    ego_y.push_back(y);
  }

  void publishQPPlanningResult(const std::vector<TrajectoryPoint>& result_path) {
    em_planner_ros::PlanningResult msg;
    for (const auto& pt : result_path) {
      em_planner_ros::TrajectoryPoint pt_msg;
      pt_msg.index = pt.index;
      pt_msg.x = pt.x;
      pt_msg.y = pt.y;
      pt_msg.angle = pt.angle;
      pt_msg.xg = pt.xg;
      pt_msg.yg = pt.yg;
      pt_msg.zg = pt.zg;
      pt_msg.global_angle = pt.global_angle;
      pt_msg.curvature = pt.curvature;
      pt_msg.d_curvature = pt.d_curvature;
      pt_msg.direction = pt.direction;
      pt_msg.length = pt.length;
      pt_msg.v = pt.v;
      pt_msg.a = pt.a;
      pt_msg.t = pt.t;
      
      pt_msg.frenet_info.s = pt.frenet_info.s ;
      pt_msg.frenet_info.s_d = pt.frenet_info.s_d ;
      pt_msg.frenet_info.s_dd = pt.frenet_info.s_dd ;
      pt_msg.frenet_info.s_ddd = pt.frenet_info.s_ddd ;
      pt_msg.frenet_info.l = pt.frenet_info.l ;
      pt_msg.frenet_info.l_d = pt.frenet_info.l_d ;
      pt_msg.frenet_info.l_dd = pt.frenet_info.l_dd ;
      pt_msg.frenet_info.l_ddd = pt.frenet_info.l_ddd ;
      pt_msg.frenet_info.l_ds = pt.frenet_info.l_ds ;
      pt_msg.frenet_info.l_dds = pt.frenet_info.l_dds ;
      pt_msg.frenet_info.l_ddds = pt.frenet_info.l_ddds ;
      pt_msg.frenet_info.ds = pt.frenet_info.ds ;

      msg.trajectory.push_back(pt_msg);
      }
    qp_result_pub_.publish(msg);
  }

  void publishQPSpeedResult( const std::vector<TrajectoryPoint>& result_speed  ){
    em_planner_ros::PlanningResult msg;
    double last_s = NAN; // 初始化无效值标记
    const double TIME_INTERVAL = 0.1; // 固定时间间隔
    
    // 使用索引循环访问路径点
    for (size_t i = 0; i < result_speed.size(); ++i) {
        const auto& pt = result_speed[i];
        em_planner_ros::TrajectoryPoint pt_msg;
        
        // 标准字段赋值
        pt_msg.index = pt.index;
        pt_msg.x = pt.x;
        pt_msg.y = pt.y;
        pt_msg.angle = pt.angle;
        pt_msg.xg = pt.xg;
        pt_msg.yg = pt.yg;
        pt_msg.zg = pt.zg;
        pt_msg.global_angle = pt.global_angle;
        pt_msg.curvature = pt.curvature;
        pt_msg.d_curvature = pt.d_curvature;
        pt_msg.direction = pt.direction;
        pt_msg.length = pt.length;
        pt_msg.a = pt.a;
        pt_msg.t = pt.t;

        // 关键修改：速度计算逻辑
        if (std::isnan(last_s)) {
            // 第一个点：无前一时刻数据
            pt_msg.v = ego_v ;  // 可考虑使用 pt.v 作为替代方案
        } else {
            // 核心算法：v = Δs / Δt
            double delta_s = pt.frenet_info.s - last_s;
            pt_msg.v = delta_s / TIME_INTERVAL;
        }
        last_s = pt.frenet_info.s;  // 更新存储值

        // Frenet信息赋值
        pt_msg.frenet_info.s = pt.frenet_info.s ;
        pt_msg.frenet_info.s_d = pt.frenet_info.s_d ;
        pt_msg.frenet_info.s_dd = pt.frenet_info.s_dd ;
        pt_msg.frenet_info.s_ddd = pt.frenet_info.s_ddd ;
        pt_msg.frenet_info.l = pt.frenet_info.l ;
        pt_msg.frenet_info.l_d = pt.frenet_info.l_d ;
        pt_msg.frenet_info.l_dd = pt.frenet_info.l_dd ;
        pt_msg.frenet_info.l_ddd = pt.frenet_info.l_ddd ;
        pt_msg.frenet_info.l_ds = pt.frenet_info.l_ds ;
        pt_msg.frenet_info.l_dds = pt.frenet_info.l_dds ;
        pt_msg.frenet_info.l_ddds = pt.frenet_info.l_ddds ;
        pt_msg.frenet_info.ds = pt.frenet_info.ds ;

        msg.trajectory.push_back(pt_msg);
    }
    qp_speed_pub_.publish(msg);
  }
  
  void publishDPPlanningResult(const std::vector<TrajectoryPoint>& result_path) {
    em_planner_ros::PlanningResult msg;
    for (const auto& pt : result_path) {
      em_planner_ros::TrajectoryPoint pt_msg;
      pt_msg.index = pt.index;
      pt_msg.x = pt.x;
      pt_msg.y = pt.y;
      pt_msg.angle = pt.angle;
      pt_msg.xg = pt.xg;
      pt_msg.yg = pt.yg;
      pt_msg.zg = pt.zg;
      pt_msg.global_angle = pt.global_angle;
      pt_msg.curvature = pt.curvature;
      pt_msg.d_curvature = pt.d_curvature;
      pt_msg.direction = pt.direction;
      pt_msg.length = pt.length;
      pt_msg.v = pt.v;
      pt_msg.a = pt.a;
      pt_msg.t = pt.t;

      pt_msg.frenet_info.s = pt.frenet_info.s ;
      pt_msg.frenet_info.s_d = pt.frenet_info.s_d ;
      pt_msg.frenet_info.s_dd = pt.frenet_info.s_dd ;
      pt_msg.frenet_info.s_ddd = pt.frenet_info.s_ddd ;
      pt_msg.frenet_info.l = pt.frenet_info.l ;
      pt_msg.frenet_info.l_d = pt.frenet_info.l_d ;
      pt_msg.frenet_info.l_dd = pt.frenet_info.l_dd ;
      pt_msg.frenet_info.l_ddd = pt.frenet_info.l_ddd ;
      pt_msg.frenet_info.l_ds = pt.frenet_info.l_ds ;
      pt_msg.frenet_info.l_dds = pt.frenet_info.l_dds ;
      pt_msg.frenet_info.l_ddds = pt.frenet_info.l_ddds ;
      pt_msg.frenet_info.ds = pt.frenet_info.ds ;

      msg.trajectory.push_back(pt_msg);
      }
    dp_result_pub_.publish(msg);
  }
};
  // 构造函数定义
  PlannerNode::PlannerNode() {
    qp_result_pub_ = nh_.advertise<em_planner_ros::PlanningResult>("qp_planning_result", 10);
    qp_speed_pub_ = nh_.advertise<em_planner_ros::PlanningResult>("qp_speed_result", 10);
    dp_result_pub_ = nh_.advertise<em_planner_ros::PlanningResult>("dp_planning_result", 10);

    refline_sub_   = nh_.subscribe("reference_line", 1, &PlannerNode::referenceLineCallback, this);
    obstacles_sub_ = nh_.subscribe("obstacle_list", 1, &PlannerNode::obstacleCallback, this);
    localization_sub_ = nh_.subscribe("localization", 1, &PlannerNode::localizationCallback, this);
  }

  void PlannerNode::referenceLineCallback(const em_planner_ros::PlanningResult::ConstPtr& msg) {
    reference_line_.clear();
    for (const auto& pt_msg : msg->trajectory) {
      TrajectoryPoint pt;
      pt.index = pt_msg.index;
      pt.x = pt_msg.x;
      pt.y = pt_msg.y;
      pt.angle = pt_msg.angle;
      pt.xg = pt_msg.xg;
      pt.yg = pt_msg.yg;
      pt.zg = pt_msg.zg;
      pt.global_angle = pt_msg.global_angle;
      pt.curvature = pt_msg.curvature;
      pt.d_curvature = pt_msg.d_curvature;
      pt.direction = pt_msg.direction;
      pt.length = pt_msg.length;
      pt.v = pt_msg.v;
      pt.a = pt_msg.a;
      pt.t = pt_msg.t;
      pt.frenet_info.s = pt_msg.frenet_info.s ;
      pt.frenet_info.s_d = pt_msg.frenet_info.s_d ;
      pt.frenet_info.s_dd = pt_msg.frenet_info.s_dd ;
      pt.frenet_info.s_ddd = pt_msg.frenet_info.s_ddd ;
      pt.frenet_info.l = pt_msg.frenet_info.l ;
      pt.frenet_info.l_d = pt_msg.frenet_info.l_d ;
      pt.frenet_info.l_dd = pt_msg.frenet_info.l_dd ;
      pt.frenet_info.l_ddd = pt_msg.frenet_info.l_ddd ;
      pt.frenet_info.l_ds = pt_msg.frenet_info.l_ds ;
      pt.frenet_info.l_dds = pt_msg.frenet_info.l_dds ;
      pt.frenet_info.l_ddds = pt_msg.frenet_info.l_ddds ;
      pt.frenet_info.ds = pt_msg.frenet_info.ds ;

      reference_line_.push_back(pt);
    }
  }

  void PlannerNode::obstacleCallback(const em_planner_ros::ObstacleList::ConstPtr& msg) {
    obs_.obstacle_list.clear();

    for (const auto& obs_msg : msg->obstacle_list) {
      Obstacle obs;
      obs.id = obs_msg.id;
      obs.type = obs_msg.type;
      obs.width = obs_msg.width;
      obs.length = obs_msg.length;
      obs.height = obs_msg.height;
      obs.confidence = obs_msg.confidence;
      obs.age = obs_msg.age;

      // 拷贝 traj_p 字段
      obs.traj_p.index = obs_msg.traj_p.index;
      obs.traj_p.x = obs_msg.traj_p.x;
      obs.traj_p.y = obs_msg.traj_p.y;
      obs.traj_p.angle = obs_msg.traj_p.angle;
      obs.traj_p.xg = obs_msg.traj_p.xg;
      obs.traj_p.yg = obs_msg.traj_p.yg;
      obs.traj_p.zg = obs_msg.traj_p.zg;
      obs.traj_p.global_angle = obs_msg.traj_p.global_angle;
      obs.traj_p.curvature = obs_msg.traj_p.curvature;
      obs.traj_p.d_curvature = obs_msg.traj_p.d_curvature;
      obs.traj_p.direction = obs_msg.traj_p.direction;
      obs.traj_p.length = obs_msg.traj_p.length;
      obs.traj_p.v = obs_msg.traj_p.v;
      obs.traj_p.a = obs_msg.traj_p.a;
      obs.traj_p.t = obs_msg.traj_p.t;

      // 如不使用 obstacle_list_history，可忽略
      obs_.obstacle_list.push_back(obs);
    }
  }

  void PlannerNode::localizationCallback(const em_planner_ros::Localization::ConstPtr& msg) {
  current_pose_.xg = msg->xg;
  current_pose_.yg = msg->yg;
  current_pose_.zg = msg->zg;
  current_pose_.global_angle = msg->yaw;
  current_pose_.x = msg->xg;  // 如果你使用的是局部平面坐标，x=yaw坐标一致
  current_pose_.y = msg->yg;
  current_pose_.angle = msg->yaw;

  // 你也可以根据需要设置速度、加速度等其他字段
  }


  void PlannerNode::run() {
  // int main(int argc, char** argv) {
  
    // step1--获取规划起点x,y,global_angle,v(vx,vy),a(ax,ay)
    TrajectoryPoint start_point;

    // start_point = FindFrenetProjPoint(sce_1.referenceLine_, 5);  //这个被他下四行替代掉。
    if (reference_line_.empty()) {
      ROS_WARN("Reference line not received yet.");
      return;
    }
    // start_point = FindFrenetProjPoint(reference_line_, 5);
    start_point = current_pose_; 
    // start_point.frenet_info.s += 5;
    start_point.v = ego_v; 
    ROS_INFO_STREAM("[ego_v]: " <<  start_point.v);
    // step2--根据规划起点更新参考线的s
    // updateRefLineS(start_point, sce_1.referenceLine_); //这个被他下1行替代掉。
    updateRefLineS(start_point, reference_line_);

    

    // step3--获取起点的frenet_info
    // CartesianToFrenet(start_point, sce_1.referenceLine_);
    CartesianToFrenet(start_point, reference_line_);

    // step3--更新障碍物的s,l
    for (auto& obs : obs_.obstacle_list) { //sce_1.
      CartesianToFrenet(obs.traj_p, reference_line_);  //sce_1.referenceLine_   reference_line_
    }
    
    // ============== 新增障碍物计数和过滤 ============== //
    // 过滤前计数
    size_t original_count = obs_.obstacle_list.size();
    ROS_INFO("[障碍物过滤] 过滤前障碍物数量: %zu", original_count);

    if(original_count > 0) {
        // 打印当前位置信息
        ROS_INFO("[障碍物过滤] 当前车辆位置: s=%.2f", current_pose_.frenet_info.s);
        
        const double ego_s = current_pose_.frenet_info.s - 3.0;  // 计算阈值
        ROS_INFO("[障碍物过滤] 过滤阈值: s<%.2f", ego_s);

        // 使用remove-erase惯用法高效删除元素
        auto& obstacles = obs_.obstacle_list;
        auto it = std::remove_if(obstacles.begin(), obstacles.end(),
            [&](const auto& obs) {
                return obs.traj_p.frenet_info.s < ego_s;
            });
        
        // 计算将被删除的障碍物数量
        size_t removed_count = std::distance(it, obstacles.end());
        
        // 执行删除
        obstacles.erase(it, obstacles.end());
        
        // 过滤后计数
        ROS_INFO("[障碍物过滤] 已移除后方障碍物数量: %zu", removed_count);
        ROS_INFO("[障碍物过滤] 过滤后障碍物数量: %zu", obstacles.size());
    } else {
        ROS_INFO("[障碍物过滤] 无障碍物可过滤");
    }
    // ============== 新增代码结束 ============== //


    EMPlanner em_planner(start_point, reference_line_ ,  //sce_1.referenceLine_ reference_line_
                        obs_.obstacle_list);    //sce_1.

    em_planner.Plan();
    for (const auto& pt : em_planner.st_path_) {
    ROS_INFO_STREAM("[st_path] t: " << std::fixed << std::setprecision(2) << pt.t
                    << " s: " << pt.frenet_info.s
                    << " v: " << pt.v);
    }

    // Step 6: 获取结果并发布（假设 result_path 是 public 成员或 get 方法）
    const auto& result_path = em_planner.qp_path_;    
    publishQPPlanningResult(result_path);

    const auto& qp_speed = em_planner.qp_speed_;
    publishQPSpeedResult(qp_speed);

    const auto& result_dp_path = em_planner.dp_path_;
    publishDPPlanningResult(result_dp_path);
    
    // return 0;
  }

bool is_plot_closed = false;  // 全局变量  
void plot_speed_cb(const em_planner_ros::PlanningResult::ConstPtr& msg) {
    if (is_plot_closed) {
        return;  // 如果图窗已关闭，直接返回，不执行绘图
    }
        std::vector<double> t_vec, v_vec;
        for (const auto& pt : msg->trajectory) {
            t_vec.push_back(pt.t);
            v_vec.push_back(pt.v);
        }
        plt::clf();
        plt::plot(t_vec, v_vec, "b-");
        plt::xlabel("t (s)");
        plt::ylabel("v (m/s)");
        // plt::pause(0.001);
}
int main(int argc, char** argv) {
    ros::init(argc, argv, "planner_node");
    PlannerNode node;

     // 启动画图线程
    std::thread([]() {
    ros::NodeHandle nh;
    ros::Subscriber sub = nh.subscribe<em_planner_ros::PlanningResult>(
        "/qp_speed_result", 1,
        std::bind(&plot_speed_cb, std::placeholders::_1)
    );


    ros::spin();
    }).detach();

    ros::Rate rate(1);  // 1 Hz

    // 等待初始数据
    ros::Time start = ros::Time::now();
    while (ros::ok() && node.reference_line_.empty() && node.obs_.obstacle_list.empty()) {
        ros::spinOnce();
        rate.sleep();
        if ((ros::Time::now() - start).toSec() > 10.0) {
            ROS_ERROR("Timeout waiting for reference_line.");
            return 1;
        }
    }

    // 主循环：每 1 秒运行一次规划
    while (ros::ok()) {
        node.run();        // 执行一次规划
        ros::spinOnce();   // 处理订阅消息
        rate.sleep();      // 控制频率为 1 Hz
    }

    return 0;
}
