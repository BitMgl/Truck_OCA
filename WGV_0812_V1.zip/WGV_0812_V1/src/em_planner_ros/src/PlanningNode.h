#include <ros/ros.h>
#include <iostream>
#include <map>
#include <string>

#include "matplotlibcpp.h"
#include "em_planner.h"
#include "sce1.h"
#include "sce2.h"
#include "sce3.h"
#include "sce4.h"
#include <thread>

#include "em_planner_ros/PlanningResult.h"
#include "em_planner_ros/TrajectoryPoint.h"
#include "em_planner_ros/ObstacleList.h"
#include "em_planner_ros/Obstacle.h"
#include "em_planner_ros/Localization.h"
#include "drifting_common/INS.h"
#include <geometry_msgs/Vector3.h>

#include <cmath>
#include <Eigen/Dense>


namespace plt = matplotlibcpp;


class PlannerNode {
public:
  PlannerNode() ; // 构造函数，里头初始化publisher
  void run();       // 原 main 函数的主要逻辑，后面我添加了publisher
  void referenceLineCallback(const em_planner_ros::PlanningResult::ConstPtr& msg);
  void obstacleCallback(const em_planner_ros::ObstacleList::ConstPtr& msg);
  void localizationCallback(const em_planner_ros::Localization::ConstPtr& msg);
  void localizationRealCallback(const drifting_common::INS::ConstPtr& msg);
  void OffsetCallback(const geometry_msgs::Vector3::ConstPtr& msg);
  std::vector<TrajectoryPoint> reference_line_;
  ObstacleList obs_;
  TrajectoryPoint current_pose_;
  std::vector<TrajectoryPoint> Last_Trajectory_;
  std::mutex plt_mtx_;                 // 保护下面 4 个向量
  std::vector<double> dp_x_, dp_y_, qp_x_, qp_y_, ub_, lb_, obs_x_, obs_y_, dp_v_, qp_v_ ;
  double dt_of_plan = 1; //规划周期是1秒。
  geometry_msgs::Vector3 start_global_vector3;

private:
  ros::NodeHandle nh_;
  ros::Publisher qp_result_pub_;
  ros::Publisher qp_speed_pub_;
  ros::Publisher dp_speed_pub_;
  ros::Publisher dp_result_pub_;

  ros::Subscriber refline_sub_;
  ros::Subscriber obstacles_sub_; //需要加什么新的subscriber直接在这个后面加。
  ros::Subscriber localization_sub_;
  ros::Subscriber localization_real_sub_;
  ros::Subscriber start_global_sub_;
  



  void rotate(std::vector<double>& ego_x, std::vector<double>& ego_y, double x,
              double y, double x_center, double y_center, double theta) {
    double rad = theta;  // 弧度
    double d = 2.236;    // 计算点之间的距离
    double alpha =
        std::atan2(y - y_center, x - x_center);  // 计算点 a 相对于点 b 的方位角
    alpha += rad;                                // 增加角度
    x = x_center + d * std::cos(alpha);  // 更新点 a 的 x 坐标
    y = y_center + d * std::sin(alpha);  // 更新点 a 的 y 坐标
    ego_x.push_back(x);
    ego_y.push_back(y);
  }

  void publishQPPlanningResult(const std::vector<TrajectoryPoint>& result_path) {
    em_planner_ros::PlanningResult msg;
    for (const auto& pt : result_path) {
      em_planner_ros::TrajectoryPoint pt_msg;
      pt_msg.index = pt.index;
      pt_msg.x = pt.x;
      pt_msg.y = pt.y;
      pt_msg.angle = pt.angle;
      pt_msg.xg = pt.xg;
      pt_msg.yg = pt.yg;
      pt_msg.zg = pt.zg;
      pt_msg.global_angle = pt.global_angle;
      pt_msg.curvature = pt.curvature;
      pt_msg.d_curvature = pt.d_curvature;
      pt_msg.direction = pt.direction;
      pt_msg.length = pt.length;
      pt_msg.v = pt.v;
      pt_msg.a = pt.a;
      pt_msg.t = pt.t;
      
      pt_msg.frenet_info.s = pt.frenet_info.s ;
      pt_msg.frenet_info.s_d = pt.frenet_info.s_d ;
      pt_msg.frenet_info.s_dd = pt.frenet_info.s_dd ;
      pt_msg.frenet_info.s_ddd = pt.frenet_info.s_ddd ;
      pt_msg.frenet_info.l = pt.frenet_info.l ;
      pt_msg.frenet_info.l_d = pt.frenet_info.l_d ;
      pt_msg.frenet_info.l_dd = pt.frenet_info.l_dd ;
      pt_msg.frenet_info.l_ddd = pt.frenet_info.l_ddd ;
      pt_msg.frenet_info.l_ds = pt.frenet_info.l_ds ;
      pt_msg.frenet_info.l_dds = pt.frenet_info.l_dds ;
      pt_msg.frenet_info.l_ddds = pt.frenet_info.l_ddds ;
      pt_msg.frenet_info.ds = pt.frenet_info.ds ;

      msg.trajectory.push_back(pt_msg);
      }
    qp_result_pub_.publish(msg);
  }

  void publishQPSpeedResult( const std::vector<TrajectoryPoint>& result_speed  ){
    em_planner_ros::PlanningResult msg;
    double last_s = NAN; // 初始化无效值标记
    const double TIME_INTERVAL = 0.1; // 固定时间间隔
    qp_v_.clear();
    // 使用索引循环访问路径点
    for (size_t i = 0; i < result_speed.size(); ++i) {
        const auto& pt = result_speed[i];
        em_planner_ros::TrajectoryPoint pt_msg;
        
        // 标准字段赋值
        pt_msg.index = pt.index;
        pt_msg.x = pt.x;
        pt_msg.y = pt.y;
        pt_msg.angle = pt.angle;
        pt_msg.xg = pt.xg;
        pt_msg.yg = pt.yg;
        pt_msg.zg = pt.zg;
        pt_msg.global_angle = pt.global_angle;
        pt_msg.curvature = pt.curvature;
        pt_msg.d_curvature = pt.d_curvature;
        pt_msg.direction = pt.direction;
        pt_msg.length = pt.length;
        pt_msg.a = pt.a;
        pt_msg.t = pt.t;

        // 关键修改：速度计算逻辑
        if (std::isnan(last_s)) {
            // 第一个点：无前一时刻数据
            pt_msg.v = 0 ;  // 可考虑使用 pt.v 作为替代方案
        } else {
            // 核心算法：v = Δs / Δt
            double delta_s = pt.frenet_info.s - last_s;
            pt_msg.v = delta_s / TIME_INTERVAL;
            
        }
        last_s = pt.frenet_info.s;  // 更新存储值
        
        // Frenet信息赋值
        pt_msg.frenet_info.s = pt.frenet_info.s ;
        pt_msg.frenet_info.s_d = pt.frenet_info.s_d ;
        pt_msg.frenet_info.s_dd = pt.frenet_info.s_dd ;
        pt_msg.frenet_info.s_ddd = pt.frenet_info.s_ddd ;
        pt_msg.frenet_info.l = pt.frenet_info.l ;
        pt_msg.frenet_info.l_d = pt.frenet_info.l_d ;
        pt_msg.frenet_info.l_dd = pt.frenet_info.l_dd ;
        pt_msg.frenet_info.l_ddd = pt.frenet_info.l_ddd ;
        pt_msg.frenet_info.l_ds = pt.frenet_info.l_ds ;
        pt_msg.frenet_info.l_dds = pt.frenet_info.l_dds ;
        pt_msg.frenet_info.l_ddds = pt.frenet_info.l_ddds ;
        pt_msg.frenet_info.ds = pt.frenet_info.ds ;

        msg.trajectory.push_back(pt_msg);
        qp_v_.push_back(pt_msg.v);
    }
    msg.trajectory[0].v=msg.trajectory[1].v;
    qp_v_[0] = qp_v_[1];
    qp_speed_pub_.publish(msg);
  }
  
void publishDPSpeedResult( const std::vector<TrajectoryPoint>& result_speed  ){
    em_planner_ros::PlanningResult msg;
    double last_s = NAN; // 初始化无效值标记
    const double TIME_INTERVAL = 0.1; // 固定时间间隔
    dp_v_.clear();
    // 使用索引循环访问路径点
    for (size_t i = 0; i < result_speed.size(); ++i) {
        const auto& pt = result_speed[i];
        em_planner_ros::TrajectoryPoint pt_msg;
        
        // 标准字段赋值
        pt_msg.index = pt.index;
        pt_msg.x = pt.x;
        pt_msg.y = pt.y;
        pt_msg.angle = pt.angle;
        pt_msg.xg = pt.xg;
        pt_msg.yg = pt.yg;
        pt_msg.zg = pt.zg;
        pt_msg.global_angle = pt.global_angle;
        pt_msg.curvature = pt.curvature;
        pt_msg.d_curvature = pt.d_curvature;
        pt_msg.direction = pt.direction;
        pt_msg.length = pt.length;
        pt_msg.a = pt.a;
        pt_msg.t = pt.t;

        // 关键修改：速度计算逻辑
        if (std::isnan(last_s)) {
            // 第一个点：无前一时刻数据
            pt_msg.v = 0 ;  // 可考虑使用 pt.v 作为替代方案
        } else {
            // 核心算法：v = Δs / Δt
            double delta_s = pt.frenet_info.s - last_s;
            pt_msg.v = delta_s / TIME_INTERVAL;
           
        }
        last_s = pt.frenet_info.s;  // 更新存储值
        
        // Frenet信息赋值
        pt_msg.frenet_info.s = pt.frenet_info.s ;
        pt_msg.frenet_info.s_d = pt.frenet_info.s_d ;
        pt_msg.frenet_info.s_dd = pt.frenet_info.s_dd ;
        pt_msg.frenet_info.s_ddd = pt.frenet_info.s_ddd ;
        pt_msg.frenet_info.l = pt.frenet_info.l ;
        pt_msg.frenet_info.l_d = pt.frenet_info.l_d ;
        pt_msg.frenet_info.l_dd = pt.frenet_info.l_dd ;
        pt_msg.frenet_info.l_ddd = pt.frenet_info.l_ddd ;
        pt_msg.frenet_info.l_ds = pt.frenet_info.l_ds ;
        pt_msg.frenet_info.l_dds = pt.frenet_info.l_dds ;
        pt_msg.frenet_info.l_ddds = pt.frenet_info.l_ddds ;
        pt_msg.frenet_info.ds = pt.frenet_info.ds ;

        msg.trajectory.push_back(pt_msg);
        dp_v_.push_back(pt_msg.v);
    }
    msg.trajectory[0].v= msg.trajectory[1].v;
    dp_v_[0] = dp_v_[1];
  }

  void publishDPPlanningResult(const std::vector<TrajectoryPoint>& result_path) {
    em_planner_ros::PlanningResult msg;
    for (const auto& pt : result_path) {
      em_planner_ros::TrajectoryPoint pt_msg;
      pt_msg.index = pt.index;
      pt_msg.x = pt.x;
      pt_msg.y = pt.y;
      pt_msg.angle = pt.angle;
      pt_msg.xg = pt.xg;
      pt_msg.yg = pt.yg;
      pt_msg.zg = pt.zg;
      pt_msg.global_angle = pt.global_angle;
      pt_msg.curvature = pt.curvature;
      pt_msg.d_curvature = pt.d_curvature;
      pt_msg.direction = pt.direction;
      pt_msg.length = pt.length;
      pt_msg.v = pt.v;
      pt_msg.a = pt.a;
      pt_msg.t = pt.t;

      pt_msg.frenet_info.s = pt.frenet_info.s ;
      pt_msg.frenet_info.s_d = pt.frenet_info.s_d ;
      pt_msg.frenet_info.s_dd = pt.frenet_info.s_dd ;
      pt_msg.frenet_info.s_ddd = pt.frenet_info.s_ddd ;
      pt_msg.frenet_info.l = pt.frenet_info.l ;
      pt_msg.frenet_info.l_d = pt.frenet_info.l_d ;
      pt_msg.frenet_info.l_dd = pt.frenet_info.l_dd ;
      pt_msg.frenet_info.l_ddd = pt.frenet_info.l_ddd ;
      pt_msg.frenet_info.l_ds = pt.frenet_info.l_ds ;
      pt_msg.frenet_info.l_dds = pt.frenet_info.l_dds ;
      pt_msg.frenet_info.l_ddds = pt.frenet_info.l_ddds ;
      pt_msg.frenet_info.ds = pt.frenet_info.ds ;

      msg.trajectory.push_back(pt_msg);
      }
    dp_result_pub_.publish(msg);
  }
};
  // 构造函数定义
  PlannerNode::PlannerNode() {
    qp_result_pub_ = nh_.advertise<em_planner_ros::PlanningResult>("qp_planning_result", 10);
    qp_speed_pub_ = nh_.advertise<em_planner_ros::PlanningResult>("qp_speed_result", 10);
    dp_speed_pub_ = nh_.advertise<em_planner_ros::PlanningResult>("dp_speed_result", 10);
    dp_result_pub_ = nh_.advertise<em_planner_ros::PlanningResult>("dp_planning_result", 10);

    refline_sub_   = nh_.subscribe("reference_line", 1, &PlannerNode::referenceLineCallback, this);
    obstacles_sub_ = nh_.subscribe("obstacle_list", 1, &PlannerNode::obstacleCallback, this);
    localization_sub_ = nh_.subscribe("localization", 1, &PlannerNode::localizationCallback, this);
    localization_real_sub_ = nh_.subscribe("drifting/ins", 1, &PlannerNode::localizationRealCallback, this);
    start_global_sub_ = nh_.subscribe("start_global_pose", 1, &PlannerNode::OffsetCallback, this);
  }

  void PlannerNode::referenceLineCallback(const em_planner_ros::PlanningResult::ConstPtr& msg) {
    reference_line_.clear();
    for (const auto& pt_msg : msg->trajectory) {
      TrajectoryPoint pt;
      pt.index = pt_msg.index;
      pt.x = pt_msg.x;
      pt.y = pt_msg.y;
      pt.angle = pt_msg.angle;
      pt.xg = pt_msg.xg;
      pt.yg = pt_msg.yg;
      pt.zg = pt_msg.zg;
      pt.global_angle = pt_msg.global_angle;
      pt.curvature = pt_msg.curvature;
      pt.d_curvature = pt_msg.d_curvature;
      pt.direction = pt_msg.direction;
      pt.length = pt_msg.length;
      pt.v = pt_msg.v;
      pt.a = pt_msg.a;
      pt.t = pt_msg.t;
      pt.frenet_info.s = pt_msg.frenet_info.s ;
      pt.frenet_info.s_d = pt_msg.frenet_info.s_d ;
      pt.frenet_info.s_dd = pt_msg.frenet_info.s_dd ;
      pt.frenet_info.s_ddd = pt_msg.frenet_info.s_ddd ;
      pt.frenet_info.l = pt_msg.frenet_info.l ;
      pt.frenet_info.l_d = pt_msg.frenet_info.l_d ;
      pt.frenet_info.l_dd = pt_msg.frenet_info.l_dd ;
      pt.frenet_info.l_ddd = pt_msg.frenet_info.l_ddd ;
      pt.frenet_info.l_ds = pt_msg.frenet_info.l_ds ;
      pt.frenet_info.l_dds = pt_msg.frenet_info.l_dds ;
      pt.frenet_info.l_ddds = pt_msg.frenet_info.l_ddds ;
      pt.frenet_info.ds = pt_msg.frenet_info.ds ;

      reference_line_.push_back(pt);
    }
  }

  void PlannerNode::obstacleCallback(const em_planner_ros::ObstacleList::ConstPtr& msg) {
    obs_.obstacle_list.clear();

    for (const auto& obs_msg : msg->obstacle_list) {
      Obstacle obs;
      obs.id = obs_msg.id;
      obs.type = obs_msg.type;
      obs.width = obs_msg.width;
      obs.length = obs_msg.length;
      obs.height = obs_msg.height;
      obs.confidence = obs_msg.confidence;
      obs.age = obs_msg.age;

      // 拷贝 traj_p 字段
      obs.traj_p.index = obs_msg.traj_p.index;
      obs.traj_p.x = obs_msg.traj_p.x;
      obs.traj_p.y = obs_msg.traj_p.y;
      obs.traj_p.angle = obs_msg.traj_p.angle;
      obs.traj_p.xg = obs_msg.traj_p.xg;
      obs.traj_p.yg = obs_msg.traj_p.yg;
      obs.traj_p.zg = obs_msg.traj_p.zg;
      obs.traj_p.global_angle = obs_msg.traj_p.global_angle;
      obs.traj_p.curvature = obs_msg.traj_p.curvature;
      obs.traj_p.d_curvature = obs_msg.traj_p.d_curvature;
      obs.traj_p.direction = obs_msg.traj_p.direction;
      obs.traj_p.length = obs_msg.traj_p.length;
      obs.traj_p.v = obs_msg.traj_p.v;
      obs.traj_p.a = obs_msg.traj_p.a;
      obs.traj_p.t = obs_msg.traj_p.t;

      // 如不使用 obstacle_list_history，可忽略
      obs_.obstacle_list.push_back(obs);
    }
  }

  void PlannerNode::localizationCallback(const em_planner_ros::Localization::ConstPtr& msg) {
  current_pose_.xg = msg->xg;
  current_pose_.yg = msg->yg;
  current_pose_.zg = msg->zg;
  current_pose_.global_angle = msg->yaw;
  current_pose_.x = msg->xg;  // 如果你使用的是局部平面坐标，x=yaw坐标一致
  current_pose_.y = msg->yg;
  current_pose_.angle = msg->yaw;
  current_pose_.v = msg->vg;

  // 你也可以根据需要设置速度、加速度等其他字段
  }

  void PlannerNode::localizationRealCallback(const drifting_common::INS::ConstPtr& msg) {
  current_pose_.xg = msg->INS_X - start_global_vector3.x; //441557.0;
  current_pose_.yg = msg->INS_Y - start_global_vector3.y; //4423324.0;
  // current_pose_.zg = msg->INS_LocatHeight;
  current_pose_.global_angle = msg->INS_HeadingAngle - start_global_vector3.z;
  current_pose_.x = 0; //msg->INS_X;  // 如果你使用的是局部平面坐标，x=yaw坐标一致
  current_pose_.y = 0;//msg->INS_Y;
  current_pose_.angle = 0; //msg->INS_HeadingAngle
  current_pose_.v = sqrt(pow(msg->INS_vx,2)+pow(msg->INS_vy,2));
  std::cout<<"get real localization"<<std::endl;  // 你也可以根据需要设置速度、加速度等其他字段
  }

  void PlannerNode::OffsetCallback(const geometry_msgs::Vector3::ConstPtr& msg)
{// 更新全局变量
  start_global_vector3 = *msg;
  
  ROS_DEBUG("Received new vector: x=%.2f, y=%.2f, z=%.2f", 
            msg->x, msg->y, msg->z);
}

  TrajectoryPoint  CalculatePlanStart(double dt_of_plan, TrajectoryPoint current_pose_,std::vector<TrajectoryPoint>Last_Trajectory_) 
  {
    if(Last_Trajectory_.empty())
     return current_pose_ ;
    TrajectoryPoint pre_pose_;
    // %由于不是首次运行了，有上一时刻的轨迹了，找到上一周期轨迹规划的本周期车辆应该在的位置
    int best_i0 = 0;
    double min_d = std::numeric_limits<double>::max();
    for (int i=0;i<Last_Trajectory_.size();++i)
    {
        // 计算欧氏距离
        double dx = Last_Trajectory_[i].xg - current_pose_.xg;
        double dy = Last_Trajectory_[i].yg - current_pose_.yg;
        double d  = dx * dx + dy * dy;
        if (d < min_d)
        {
            min_d = d;
            best_i0 = i;
        }
    }
    std::cout << "best_i0" <<best_i0 <<std::endl;
    // 此时 best_i0 就是最近点的索引
    double target_t = Last_Trajectory_[best_i0].t + dt_of_plan;

    std::size_t best_i = 0;
    double min_dt = std::numeric_limits<double>::max();

    for (std::size_t j = 0; j < Last_Trajectory_.size(); ++j)
    {
        double dt_of_plan = std::fabs(Last_Trajectory_[j].t - target_t);
        if (dt_of_plan < min_dt)
        {
            min_dt = dt_of_plan;
            best_i = j;
        }
    }
    std::cout << "best_i" <<best_i <<std::endl;
    // 此时 best_i 就是dt时刻时候的值。

    
    // 上一周期规划的、本周期车辆应该在的位置
    double pre_x_desire    = Last_Trajectory_[best_i].xg;
    double pre_y_desire    = Last_Trajectory_[best_i].yg;
    double pre_heading_desire = Last_Trajectory_[best_i].global_angle;

    // 切向量 / 法向量
    Eigen::Vector2d tor(std::cos(pre_heading_desire),
                        std::sin(pre_heading_desire));
    Eigen::Vector2d nor(-std::sin(pre_heading_desire),
                        std::cos(pre_heading_desire));
    double host_x = current_pose_.xg;
    double host_y = current_pose_.yg;
    double vx_cur = current_pose_.v * std::cos(current_pose_.global_angle);
    double vy_cur = current_pose_.v * std::sin(current_pose_.global_angle);
    // 误差向量
    Eigen::Vector2d d_err(host_x - pre_x_desire,
                        host_y - pre_y_desire);

    // 横 / 纵向误差（取绝对值）
    double lon_err = std::abs(d_err.dot(tor));
    double lat_err = std::abs(d_err.dot(nor));

    // 纵向误差大于2.5 横向误差大于0.5 认为控制没跟上
    if ((lon_err > 2.5)||(lat_err > 0.5))
    {    // 此分支处理控制未跟上的情况，规划起点通过运动学递推
        pre_pose_.xg = host_x + vx_cur * dt_of_plan;// + 0.5 * ax_cur * dt_of_plan * dt_of_plan;
        pre_pose_.yg = host_y + vy_cur * dt_of_plan;// + 0.5 * ay_cur * dt_of_plan * dt_of_plan;
        pre_pose_.v = std::sqrt(vx_cur*vx_cur+vy_cur*vy_cur);// + ax_cur * dt_of_plan;
        // plan_start_vy = vy_cur;// + ay_cur * dt_of_plan;
        pre_pose_.global_angle = current_pose_.global_angle;//atan2(plan_start_vy,plan_start_vx);
        // plan_start_ax = ax_cur;
        // plan_start_ay = ay_cur;
        // plan_start_kappa = kappa_cur;
        // plan_start_time = current_time + 0.1;
        
        return pre_pose_;
    }
    else
    {    // 此分支表示控制能跟的上规划，开始拼接
        pre_pose_.xg   = Last_Trajectory_[best_i].xg;
        pre_pose_.yg   = Last_Trajectory_[best_i].yg;
        pre_pose_.v    = Last_Trajectory_[best_i].v;
        pre_pose_.global_angle    = Last_Trajectory_[best_i].global_angle;
        return pre_pose_;
    }
  }

  void PlannerNode::run() {
  // int main(int argc, char** argv) {
  
    // step1--获取规划起点x,y,global_angle,v(vx,vy),a(ax,ay)
    TrajectoryPoint start_point;

    // start_point = FindFrenetProjPoint(sce_1.referenceLine_, 5);  //这个被他下四行替代掉。
    if (reference_line_.empty()) {
      ROS_WARN("Reference line not received yet.");
      return;
    }
    // start_point = FindFrenetProjPoint(reference_line_, 5);
    if (current_pose_.yg == 0) {
      ROS_WARN("Localization not received yet.");
      return;
    }
    start_point = CalculatePlanStart(dt_of_plan, current_pose_, Last_Trajectory_) ; 
    // start_point.frenet_info.s += 5;
    // ROS_INFO_STREAM("[ego_v]: " <<  start_point.v);
    // step2--根据规划起点更新参考线的s
    // updateRefLineS(start_point, sce_1.referenceLine_); //这个被他下1行替代掉。
    updateRefLineS(start_point, reference_line_);

    

    // step3--获取起点的frenet_info
    // CartesianToFrenet(start_point, sce_1.referenceLine_);
    CartesianToFrenet(start_point, reference_line_);

    // step3--更新障碍物的s,l
    for (auto& obs : obs_.obstacle_list) { //sce_1.
      CartesianToFrenet(obs.traj_p, reference_line_);  //sce_1.referenceLine_   reference_line_
    }
    
    // // ============== 新增障碍物计数和过滤 ============== //
    // // 过滤前计数
    // size_t original_count = obs_.obstacle_list.size();
    // ROS_INFO("[障碍物过滤] 过滤前障碍物数量: %zu", original_count);

    // if(original_count > 0) {
    //     // 打印当前位置信息
    //     ROS_INFO("[障碍物过滤] 当前车辆位置: s=%.2f", current_pose_.frenet_info.s);
        
    //     const double ego_s = current_pose_.frenet_info.s - 15.0;  // 计算阈值
    //     ROS_INFO("[障碍物过滤] 过滤阈值: s<%.2f", ego_s);

    //     // 使用remove-erase惯用法高效删除元素
    //     auto& obstacles = obs_.obstacle_list;
    //     auto it = std::remove_if(obstacles.begin(), obstacles.end(),
    //         [&](const auto& obs) {
    //             return obs.traj_p.frenet_info.s < ego_s;
    //         });
        
    //     // 计算将被删除的障碍物数量
    //     size_t removed_count = std::distance(it, obstacles.end());
        
    //     // 执行删除
    //     obstacles.erase(it, obstacles.end());
        
    //     // 过滤后计数
    //     ROS_INFO("[障碍物过滤] 已移除后方障碍物数量: %zu", removed_count);
    //     ROS_INFO("[障碍物过滤] 过滤后障碍物数量: %zu", obstacles.size());
    // } else {
    //     ROS_INFO("[障碍物过滤] 无障碍物可过滤");
    // }
    // // ============== 新增代码结束 ============== //


    EMPlanner em_planner(start_point, reference_line_ ,  //sce_1.referenceLine_ reference_line_
                        obs_.obstacle_list);    //sce_1.

    em_planner.Plan();
    // for (const auto& pt : em_planner.st_path_) {
    // ROS_INFO_STREAM("[st_path] t: " << std::fixed << std::setprecision(2) << pt.t
    //                 << " s: " << pt.frenet_info.s
    //                 << " v: " << pt.v);
    // }

    // store last trajectory
    Last_Trajectory_ = em_planner.st_path_;

    // Step 6: 获取结果并发布（假设 result_path 是 public 成员或 get 方法）
    const auto& result_path = em_planner.qp_path_;    
    publishQPPlanningResult(result_path);

    const auto& dp_speed = em_planner.dp_speed_;
    publishDPSpeedResult(dp_speed);

    const auto& qp_speed = em_planner.qp_speed_;
    publishQPSpeedResult(qp_speed);

    const auto& result_dp_path = em_planner.st_path_;
    publishDPPlanningResult(result_dp_path);


    
    // 画图：提取数据至成员变量
    std::lock_guard<std::mutex> lg(plt_mtx_);

    dp_x_.clear();  dp_y_.clear();
    qp_x_.clear();  qp_y_.clear();
    ub_.clear();    lb_.clear();
    obs_x_.clear(); obs_y_.clear();

    for (auto& st : em_planner.dp_speed_) {
      dp_x_.push_back(st.t);
      dp_y_.push_back(st.frenet_info.s);
    }
    for (auto& st : em_planner.qp_speed_) {
      qp_x_.push_back(st.t);
      qp_y_.push_back(st.frenet_info.s);
    }
    ub_  = em_planner.dp_speed_alg_.ub_;
    lb_  = em_planner.dp_speed_alg_.lb_;

    for (auto& obs : em_planner.dp_speed_alg_.obs_st_) {
      obs_x_.push_back(obs.tmin);
      obs_x_.push_back(obs.tmin);
      obs_x_.push_back(obs.tmax);
      obs_x_.push_back(obs.tmax);

      obs_y_.push_back(obs.sLeftMin);
      obs_y_.push_back(obs.sLeftMax);
      obs_y_.push_back(obs.sRightMax);
      obs_y_.push_back(obs.sRightMin);
    }


}


