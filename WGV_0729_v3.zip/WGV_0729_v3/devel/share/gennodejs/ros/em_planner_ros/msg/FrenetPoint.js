// Auto-generated. Do not edit!

// (in-package em_planner_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FrenetPoint {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.s = null;
      this.s_d = null;
      this.s_dd = null;
      this.s_ddd = null;
      this.l = null;
      this.l_d = null;
      this.l_dd = null;
      this.l_ddd = null;
      this.l_ds = null;
      this.l_dds = null;
      this.l_ddds = null;
      this.ds = null;
    }
    else {
      if (initObj.hasOwnProperty('s')) {
        this.s = initObj.s
      }
      else {
        this.s = 0.0;
      }
      if (initObj.hasOwnProperty('s_d')) {
        this.s_d = initObj.s_d
      }
      else {
        this.s_d = 0.0;
      }
      if (initObj.hasOwnProperty('s_dd')) {
        this.s_dd = initObj.s_dd
      }
      else {
        this.s_dd = 0.0;
      }
      if (initObj.hasOwnProperty('s_ddd')) {
        this.s_ddd = initObj.s_ddd
      }
      else {
        this.s_ddd = 0.0;
      }
      if (initObj.hasOwnProperty('l')) {
        this.l = initObj.l
      }
      else {
        this.l = 0.0;
      }
      if (initObj.hasOwnProperty('l_d')) {
        this.l_d = initObj.l_d
      }
      else {
        this.l_d = 0.0;
      }
      if (initObj.hasOwnProperty('l_dd')) {
        this.l_dd = initObj.l_dd
      }
      else {
        this.l_dd = 0.0;
      }
      if (initObj.hasOwnProperty('l_ddd')) {
        this.l_ddd = initObj.l_ddd
      }
      else {
        this.l_ddd = 0.0;
      }
      if (initObj.hasOwnProperty('l_ds')) {
        this.l_ds = initObj.l_ds
      }
      else {
        this.l_ds = 0.0;
      }
      if (initObj.hasOwnProperty('l_dds')) {
        this.l_dds = initObj.l_dds
      }
      else {
        this.l_dds = 0.0;
      }
      if (initObj.hasOwnProperty('l_ddds')) {
        this.l_ddds = initObj.l_ddds
      }
      else {
        this.l_ddds = 0.0;
      }
      if (initObj.hasOwnProperty('ds')) {
        this.ds = initObj.ds
      }
      else {
        this.ds = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrenetPoint
    // Serialize message field [s]
    bufferOffset = _serializer.float64(obj.s, buffer, bufferOffset);
    // Serialize message field [s_d]
    bufferOffset = _serializer.float64(obj.s_d, buffer, bufferOffset);
    // Serialize message field [s_dd]
    bufferOffset = _serializer.float64(obj.s_dd, buffer, bufferOffset);
    // Serialize message field [s_ddd]
    bufferOffset = _serializer.float64(obj.s_ddd, buffer, bufferOffset);
    // Serialize message field [l]
    bufferOffset = _serializer.float64(obj.l, buffer, bufferOffset);
    // Serialize message field [l_d]
    bufferOffset = _serializer.float64(obj.l_d, buffer, bufferOffset);
    // Serialize message field [l_dd]
    bufferOffset = _serializer.float64(obj.l_dd, buffer, bufferOffset);
    // Serialize message field [l_ddd]
    bufferOffset = _serializer.float64(obj.l_ddd, buffer, bufferOffset);
    // Serialize message field [l_ds]
    bufferOffset = _serializer.float64(obj.l_ds, buffer, bufferOffset);
    // Serialize message field [l_dds]
    bufferOffset = _serializer.float64(obj.l_dds, buffer, bufferOffset);
    // Serialize message field [l_ddds]
    bufferOffset = _serializer.float64(obj.l_ddds, buffer, bufferOffset);
    // Serialize message field [ds]
    bufferOffset = _serializer.float64(obj.ds, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrenetPoint
    let len;
    let data = new FrenetPoint(null);
    // Deserialize message field [s]
    data.s = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [s_d]
    data.s_d = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [s_dd]
    data.s_dd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [s_ddd]
    data.s_ddd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [l]
    data.l = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [l_d]
    data.l_d = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [l_dd]
    data.l_dd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [l_ddd]
    data.l_ddd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [l_ds]
    data.l_ds = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [l_dds]
    data.l_dds = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [l_ddds]
    data.l_ddds = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [ds]
    data.ds = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 96;
  }

  static datatype() {
    // Returns string type for a message object
    return 'em_planner_ros/FrenetPoint';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '81015cca39e519ea7fb75fe4e8fe238a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 s
    float64 s_d
    float64 s_dd
    float64 s_ddd
    float64 l
    float64 l_d
    float64 l_dd
    float64 l_ddd
    float64 l_ds
    float64 l_dds
    float64 l_ddds
    float64 ds
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrenetPoint(null);
    if (msg.s !== undefined) {
      resolved.s = msg.s;
    }
    else {
      resolved.s = 0.0
    }

    if (msg.s_d !== undefined) {
      resolved.s_d = msg.s_d;
    }
    else {
      resolved.s_d = 0.0
    }

    if (msg.s_dd !== undefined) {
      resolved.s_dd = msg.s_dd;
    }
    else {
      resolved.s_dd = 0.0
    }

    if (msg.s_ddd !== undefined) {
      resolved.s_ddd = msg.s_ddd;
    }
    else {
      resolved.s_ddd = 0.0
    }

    if (msg.l !== undefined) {
      resolved.l = msg.l;
    }
    else {
      resolved.l = 0.0
    }

    if (msg.l_d !== undefined) {
      resolved.l_d = msg.l_d;
    }
    else {
      resolved.l_d = 0.0
    }

    if (msg.l_dd !== undefined) {
      resolved.l_dd = msg.l_dd;
    }
    else {
      resolved.l_dd = 0.0
    }

    if (msg.l_ddd !== undefined) {
      resolved.l_ddd = msg.l_ddd;
    }
    else {
      resolved.l_ddd = 0.0
    }

    if (msg.l_ds !== undefined) {
      resolved.l_ds = msg.l_ds;
    }
    else {
      resolved.l_ds = 0.0
    }

    if (msg.l_dds !== undefined) {
      resolved.l_dds = msg.l_dds;
    }
    else {
      resolved.l_dds = 0.0
    }

    if (msg.l_ddds !== undefined) {
      resolved.l_ddds = msg.l_ddds;
    }
    else {
      resolved.l_ddds = 0.0
    }

    if (msg.ds !== undefined) {
      resolved.ds = msg.ds;
    }
    else {
      resolved.ds = 0.0
    }

    return resolved;
    }
};

module.exports = FrenetPoint;
