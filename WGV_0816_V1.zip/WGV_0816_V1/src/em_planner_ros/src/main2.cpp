#include "PlanningNode.h"


int main(int argc, char** argv) {
  ros::init(argc, argv, "planner_node");
  PlannerNode node;
  ros::Rate rate(1);  // 1 Hz
  // 等待初始数据
  ros::Time start = ros::Time::now();

  while (ros::ok() && node.reference_line_.empty() && node.obs_.obstacle_list.empty()) {
      ros::spinOnce();
      rate.sleep();
      if ((ros::Time::now() - start).toSec() > 10.0) {
          ROS_ERROR("Timeout waiting for reference_line.");
          return 1;
      }
  }

 
  // // 主线程负责画图
  plt::figure(1);
  plt::figure_size(1200, 600);
  plt::ion();          // 交互模式
  plt::subplot(2, 1, 1); // 显式创建并激活一个 Axes
  plt::subplot(2, 1, 2); // 显式创建并激活一个 Axes
  // // plt::figure(2);
  // // plt::figure_size(1200, 600);
  // // plt::title("velocity (v-t)");

  
  // 主循环：每 1 秒运行一次规划
  while (ros::ok()) {
      node.run();        // 执行一次规划
      ros::spinOnce();   // 处理订阅消息
      rate.sleep();      // 控制频率为 1 Hz

      // plt::clf();
      std::lock_guard<std::mutex> lg(node.plt_mtx_);
      if (!node.dp_x_.empty() ) {
        // plt::figure(1);
        plt::subplot(2, 1, 1);    // 再次激活同一个 Axes
        plt::cla(); 
        plt::title("speed plan (s-t)");
        plt::plot(node.dp_x_, node.dp_y_, "k");
        plt::plot(node.qp_x_, node.qp_y_, "g");
        plt::plot(node.dp_x_, node.ub_, "r--");
        plt::plot(node.dp_x_, node.lb_, "r--");
        std::map<std::string, std::string> kw;
        kw["color"] = "black";
        plt::fill(node.obs_x_, node.obs_y_, kw);
        
      }

      if (!node.dp_v_.empty())  {
        // ---------- 图 2：v-t ----------
        // plt::figure(1);      // 激活或创建 figure 2
        plt::subplot(2, 1, 2);  
        plt::cla(); 
        plt::title("velocity (v-t)");
        plt::plot(node.dp_x_, node.dp_v_, "k");  // 黑色：DP 速度
        plt::plot(node.qp_x_, node.qp_v_, "g");  // 绿色：QP 速度
        
      }
      plt::pause(0.1);
  }
  return 0;
}
