#include "../include/em_planner.h"
#include <yaml-cpp/yaml.h>
#include <ros/package.h>
#include <iostream>

namespace {
DpPathConfig LoadDpPathConfig(const std::string& yaml_path) {
  DpPathConfig config;
  YAML::Node cfg = YAML::LoadFile(yaml_path);
  YAML::Node dp_cfg = cfg["dp_config"];

  config.w_cost_obs = dp_cfg["w_cost_obs"].as<double>();
  config.w_cost_dl = dp_cfg["w_cost_dl"].as<double>();
  config.w_cost_ddl = dp_cfg["w_cost_ddl"].as<double>();
  config.w_cost_dddl = dp_cfg["w_cost_dddl"].as<double>();
  config.w_cost_ref = dp_cfg["w_cost_ref"].as<double>();
  config.rows = dp_cfg["rows"].as<int>();
  config.cols = dp_cfg["cols"].as<int>();
  config.sample_s = dp_cfg["sample_s"].as<double>();
  config.sample_l = dp_cfg["sample_l"].as<double>();
  config.ds = dp_cfg["ds"].as<double>();
  config.dp_square_dist_low = dp_cfg["dp_square_dist_low"].as<double>();
  config.dp_square_dist_high = dp_cfg["dp_square_dist_high"].as<double>();
  config.safe_bound_distance = dp_cfg["safe_bound_distance"].as<double>();
  config.safe_bound_ahead = dp_cfg["safe_bound_ahead"].as<double>();
  return config;
}

DpSpeedConfig LoadDpSpeedConfig(const std::string& yaml_path) {
  DpSpeedConfig config;
  YAML::Node cfg = YAML::LoadFile(yaml_path);
  auto node = cfg["dp_speed_config"];

  config.rows = node["rows"].as<int>();
  config.cols = node["cols"].as<int>();
  config.ref_v = node["ref_v"].as<double>();
  config.w_cost_obs = node["w_cost_obs"].as<double>();
  config.w_cost_ref_v = node["w_cost_ref_v"].as<double>();
  config.w_cost_a = node["w_cost_a"].as<double>();
  config.dt = node["dt"].as<double>();
  config.a_acc = node["a_acc"].as<double>();
  config.a_dec = node["a_dec"].as<double>();
  config.acc_max_cost = node["acc_max_cost"].as<double>();
  return config;
}

}

void EMPlanner::mergeTrajectory(std::vector<TrajectoryPoint>& lat_path,
                                std::vector<TrajectoryPoint>& lon_path) {
  int last_index = 0;
  for (auto& point : lon_path) {
    if (last_index > 0) last_index -= 1;
    for (; last_index < lat_path.size() - 1; last_index++) {
      // std::cout << "lon s: " << point.frenet_info.s
      //           << " lat s: " << lat_path[last_index].frenet_info.s
      //           << std::endl;
      if (point.frenet_info.s + 1e-5 >= lat_path[last_index].frenet_info.s &&
          point.frenet_info.s < lat_path[last_index + 1].frenet_info.s) {
        double proportion =
            (point.frenet_info.s - lat_path[last_index].frenet_info.s) /
            (lat_path[last_index + 1].frenet_info.s -
             lat_path[last_index].frenet_info.s);
        point.xg = lat_path[last_index].xg +
                   proportion *
                       (lat_path[last_index + 1].xg - lat_path[last_index].xg);
        point.yg = lat_path[last_index].yg +
                   proportion *
                       (lat_path[last_index + 1].yg - lat_path[last_index].yg);
        // std::cout << "lat xg: " << lat_path[last_index].xg
        //           << " lat yg: " << lat_path[last_index + 1].yg << std::endl;
        break;
      }
    }
  }
}

void EMPlanner::Plan() {
  // 获取配置文件路径
  std::string pkg_path = ros::package::getPath("em_planner_ros");
  std::string config_path = pkg_path + "/config/dp_config.yaml";

  // step1: sl dp
  DpPathConfig dp_config = LoadDpPathConfig(config_path);

  std::vector<TrajectoryPoint> obs_list;
  for (auto& obs : obs_) {
    obs_list.push_back(obs.traj_p);
  }
  dp_path_alg_.frenetDpPath(obs_list, obs_, start_point_, dp_config, dp_path_);
  dp_path_alg_.trajectoryInterp(dp_path_, dp_config);
  FrenetToCartesian(dp_path_, referenceLine_);
  dp_path_alg_.getCovexBound(dp_path_, start_point_, obs_list, obs_, dp_config);

  // step2: sl qp
  PiecewiseJerkPathProblem sl_qp(
      dp_path_alg_.ub_, dp_path_alg_.lb_, dp_config.ds,
      {start_point_.frenet_info.l, start_point_.frenet_info.l_ds,
       start_point_.frenet_info.l_dds});
  qp_path_ = dp_path_;
  bool qp_success = sl_qp.Optimize(qp_path_); //这里看qp是否成功。
  FrenetToCartesian(qp_path_, referenceLine_);
  bool flag_qp = ComputePathProfile(qp_path_);

  // step3: st dp
  DpSpeed dp_speed;
  // DpSpeedConfig dp_speed_config;
  // dp_speed_config.rows = 100;
  // dp_speed_config.cols = 8;
  // dp_speed_config.ref_v = 20;
  // dp_speed_config.w_cost_obs = 10;
  // dp_speed_config.w_cost_ref_v = 10;
  // dp_speed_config.w_cost_a = 50;
  // dp_speed_config.dt = 0.1;
  
  // step3: st dp
  std::string speed_config_path = pkg_path + "/config/dp_speed_config.yaml";
  DpSpeedConfig dp_speed_config = LoadDpSpeedConfig(speed_config_path);
  dp_speed_alg_.s_max_ = qp_path_.back().frenet_info.s;
  dp_speed_alg_.getObsStByCartesian(obs_, qp_path_);
  dp_speed_alg_.frenetDpSpeed(start_point_, dp_speed_config, dp_speed_); //
  dp_speed_alg_.trajectoryInterp(dp_speed_, dp_speed_config);
  dp_speed_alg_.getCovexBound(dp_speed_);

  // step4: st qp
  PiecewiseJerkSpeedProblem st_qp(dp_speed_alg_.ub_, dp_speed_alg_.lb_, 0.1,
                                  {0, start_point_.v, 0});
  qp_speed_ = dp_speed_;
  bool qp_speed_success = st_qp.Optimize(qp_speed_);
  if (qp_speed_success) {
      std::cout << "speed规划成功了" << std::endl;
  } else {
      std::cout << "speed规划失败了" << std::endl;
                // 2. 逐点更新
          // 提前设好初始值
          double s = 0.0;                     // 累积位移
          const double t0 = qp_speed_.empty() ? 0.0 : qp_speed_[0].t;
        
          for (size_t i = 0; i < qp_speed_.size(); ++i) {
              double dt = qp_speed_[i].t - qp_speed_[0].t;   // 以第 0 点为基准
              double new_v = start_point_.v;

              // 不允许速度反向，最小到 0
              new_v = std::max(new_v, 0.0);
              // 2) 梯形积分算位移
              if (i > 0) {                                // 第 0 点 s=0，不做积分
                  double dt_step = qp_speed_[i].t - qp_speed_[i - 1].t;
                  s += (qp_speed_[i - 1].v + new_v) * dt_step * 0.5;
              }
              // 3) 写入
              qp_speed_[i].frenet_info.s = s;

          }
          std::cout << "规划速度失败，匀速输出" << std::endl;
  }
  

  double acc_d_ = 0;
  if (qp_success) {
      std::cout << "成功了！！！" << std::endl;
      qp_path_last_ = qp_path_;
  } else {
      if (qp_path_last_.empty()) {
          std::cout << "上来就要死了，所以 qp 只能用 dp_path 了" << std::endl;
          //上来qp就死的原因大概率是把路封住了，所以干脆就急停好了！
      } else {


      // 障碍物封路检测 新检测障碍物突然出现在历史轨迹，无法通行 --------------------------  
            //首先减速。
            //接下来，我们判断这个last能不能撞到障碍物。
            //如果会撞到障碍物，急停/再判断dppath能不能撞。
            //如果不能撞到，就发last。
         for (const auto& obs : obs_) {
            std::cout<<"old_obs_s"<<"="<<obs.traj_p.frenet_info.s<<"  obs_l"<<"="<<obs.traj_p.frenet_info.l<<std::endl;
         }
        dp_speed_alg_.getObsStByCartesian(obs_, qp_path_last_);
        std::cout<<"startx"<<"="<<start_point_.xg<<"  start_y"<<"="<<start_point_.yg<<std::endl;
        std::cout<<"startx_old"<<"="<<start_point_.frenet_info.s<<"  start_y"<<"="<<start_point_.frenet_info.l<<std::endl;
        CartesianToFrenet(start_point_, qp_path_last_);
        std::cout<<"startx_new"<<"="<<start_point_.frenet_info.s<<"  start_y"<<"="<<start_point_.frenet_info.l<<std::endl;
        std::cout << "要死了，所以用上一次的！" << std::endl;
        qp_path_ = qp_path_last_;


          //首先判断last能不能撞到障碍物。
        std::vector<int> colliding_indices;   // 记录所有碰撞点的下标

        for (int i = 0; i < qp_path_last_.size(); ++i) {
            bool hit = false;
            for (const auto& obs : obs_) {
                const double obs_s0 = obs.traj_p.frenet_info.s - obs.length * 0.5;
                const double obs_s1 = obs.traj_p.frenet_info.s + obs.length * 0.5;
                const double obs_l0 = obs.traj_p.frenet_info.l - obs.width * 0.5;  //车身宽度的一半
                const double obs_l1 = obs.traj_p.frenet_info.l + obs.width * 0.5;
                if(i==1)
                {std::cout<<"obs_s"<<i<<"="<<obs.traj_p.frenet_info.s<<"  obs_l"<<i<<"="<<obs.traj_p.frenet_info.l<<std::endl;
                }
                // 计算车辆圆心到障碍物矩形的最短距离
                const double ds = std::max(0.0, std::max(obs_s0 - 0.0, 0.0 - obs_s1));
                const double dl = std::max(0.0, std::max(obs_l0 - 0.0, 0.0 - obs_l1));
                const double dist = std::sqrt(ds * ds + dl * dl);

                if (dist <= 2.0 ) {    //假设的车辆半径
                    hit = true;
                    break;   // 与任一障碍物碰撞即可标记
                }
            }
            if (hit) {
                colliding_indices.push_back(i);
            }
        }

          //如果能撞到，找到那个能撞的点。然后用距离和车速求一个制动减速度。

          //如果连续10秒都求解不出来，报问题，制动。
        // 1. 打印所有碰撞点
        std::cout << "碰撞点索引：";
        for (auto idx : colliding_indices) {
            std::cout << idx << " indx碰撞";
        }
        std::cout << std::endl;

        // 如果没有碰撞，直接退出
        if (colliding_indices.empty()) {
            std::cout << "没有碰撞点，无需减速。" << std::endl;
            acc_d_ = 0;//减速度值
        }
        else{
          // 2. 取第一个碰撞点
          const auto& first_hit = qp_path_last_[colliding_indices.front()];
          double ds = first_hit.frenet_info.s - start_point_.frenet_info.s;
          double dl = first_hit.frenet_info.l - start_point_.frenet_info.l;
          double dist = std::sqrt(ds * ds + dl * dl);   // Frenet 平面直线距离

          std::cout << "第一个碰撞点到车辆的距离 = " << dist << " m" <<  start_point_.frenet_info.s <<std::endl;

          // 3. 匀减速加速度（v² = v0² + 2aΔx）
          //    假设当前车速 v0 来自 start_point_.v
          
          double kSafeMargin = 3.0;
          if (start_point_.v < 1e-1) {
              std::cout << "车速几乎为 0，无需再减速。" << std::endl;
              acc_d_ = -2;
          } else if (dist < 1) {
              std::cout << "距离小于1米，无法计算有意义加速度。" << std::endl;
              acc_d_ = -10;
          } else {
            if (dist <= kSafeMargin) {
              std::cout << "距离过近！安全距离(" << kSafeMargin
                << " m)不足，立即全力制动！" << std::endl;
                acc_d_ = -5;
            }
            else{
              double a = -(start_point_.v * start_point_.v) / (2.0 * (dist - kSafeMargin*0.8));   // 必为负值
              std::cout << "匀减速所需加速度 a = " << a << " m/s²" << std::endl;
            }
          }
          // step4.2： 给qp_speed_重新赋值。
          // 已知：加速度 a（负值），qp_speed_ 已按时间升序排列
          // qp_speed_[i] 至少有 .t 和 .v

          if (qp_speed_.size() < 2) {
              std::cout << "qp_speed_ 点数不足，无法重算速度。" << std::endl;
              return;
          }

          // 2. 逐点更新
          // 提前设好初始值
          double s = 0.0;                     // 累积位移
          const double t0 = qp_speed_.empty() ? 0.0 : qp_speed_[0].t;
        
          for (size_t i = 0; i < qp_speed_.size(); ++i) {
              double dt = qp_speed_[i].t - qp_speed_[0].t;   // 以第 0 点为基准
              double new_v = start_point_.v + acc_d_ * dt;

              // 不允许速度反向，最小到 0
              new_v = std::max(new_v, 0.0);
              // 2) 梯形积分算位移
              if (i > 0) {                                // 第 0 点 s=0，不做积分
                  double dt_step = qp_speed_[i].t - qp_speed_[i - 1].t;
                  s += (qp_speed_[i - 1].v + new_v) * dt_step * 0.5;
              }
              // 3) 写入
              qp_speed_[i].frenet_info.s = s;

          }
          std::cout << "已按 a = " << acc_d_ << " m/s² 重算整条 qp_speed_。" << std::endl;
        }
      }
  }
  

 
  
  // step5: merge trajectory
  st_path_ = qp_speed_;
  mergeTrajectory(qp_path_, st_path_);
}