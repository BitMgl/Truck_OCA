// Auto-generated. Do not edit!

// (in-package em_planner_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Obstacle = require('./Obstacle.js');

//-----------------------------------------------------------

class ObstacleList {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.obstacle_list = null;
      this.obstacle_list_history = null;
    }
    else {
      if (initObj.hasOwnProperty('obstacle_list')) {
        this.obstacle_list = initObj.obstacle_list
      }
      else {
        this.obstacle_list = [];
      }
      if (initObj.hasOwnProperty('obstacle_list_history')) {
        this.obstacle_list_history = initObj.obstacle_list_history
      }
      else {
        this.obstacle_list_history = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ObstacleList
    // Serialize message field [obstacle_list]
    // Serialize the length for message field [obstacle_list]
    bufferOffset = _serializer.uint32(obj.obstacle_list.length, buffer, bufferOffset);
    obj.obstacle_list.forEach((val) => {
      bufferOffset = Obstacle.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [obstacle_list_history]
    // Serialize the length for message field [obstacle_list_history]
    bufferOffset = _serializer.uint32(obj.obstacle_list_history.length, buffer, bufferOffset);
    obj.obstacle_list_history.forEach((val) => {
      bufferOffset = Obstacle.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ObstacleList
    let len;
    let data = new ObstacleList(null);
    // Deserialize message field [obstacle_list]
    // Deserialize array length for message field [obstacle_list]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.obstacle_list = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.obstacle_list[i] = Obstacle.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [obstacle_list_history]
    // Deserialize array length for message field [obstacle_list_history]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.obstacle_list_history = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.obstacle_list_history[i] = Obstacle.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 256 * object.obstacle_list.length;
    length += 256 * object.obstacle_list_history.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'em_planner_ros/ObstacleList';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '665f71775aca117a71a9ee93bca615aa';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    em_planner_ros/Obstacle[] obstacle_list
    em_planner_ros/Obstacle[] obstacle_list_history
    
    
    ================================================================================
    MSG: em_planner_ros/Obstacle
    int32 type
    int32 id
    em_planner_ros/TrajectoryPoint traj_p
    float64 width
    float64 length
    float64 height
    float64 confidence
    float64 age
    
    
    ================================================================================
    MSG: em_planner_ros/TrajectoryPoint
    int32 index
    float64 x
    float64 y
    float64 angle
    float64 xg
    float64 yg
    float64 zg
    float64 global_angle
    float64 curvature
    float64 d_curvature
    int32 direction
    float64 length
    float64 v
    float64 a
    float64 t
    
    FrenetPoint frenet_info
    
    ================================================================================
    MSG: em_planner_ros/FrenetPoint
    float64 s
    float64 s_d
    float64 s_dd
    float64 s_ddd
    float64 l
    float64 l_d
    float64 l_dd
    float64 l_ddd
    float64 l_ds
    float64 l_dds
    float64 l_ddds
    float64 ds
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ObstacleList(null);
    if (msg.obstacle_list !== undefined) {
      resolved.obstacle_list = new Array(msg.obstacle_list.length);
      for (let i = 0; i < resolved.obstacle_list.length; ++i) {
        resolved.obstacle_list[i] = Obstacle.Resolve(msg.obstacle_list[i]);
      }
    }
    else {
      resolved.obstacle_list = []
    }

    if (msg.obstacle_list_history !== undefined) {
      resolved.obstacle_list_history = new Array(msg.obstacle_list_history.length);
      for (let i = 0; i < resolved.obstacle_list_history.length; ++i) {
        resolved.obstacle_list_history[i] = Obstacle.Resolve(msg.obstacle_list_history[i]);
      }
    }
    else {
      resolved.obstacle_list_history = []
    }

    return resolved;
    }
};

module.exports = ObstacleList;
