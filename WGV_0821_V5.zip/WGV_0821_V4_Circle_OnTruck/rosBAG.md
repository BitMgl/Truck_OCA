## 启动底盘
cd UGV
source roscore_init.sh

## 规划模块
cd WGV
catkin build
chmod +x start_plan.sh
./start_plan.sh

## 录制 + 命名
rosbag record /chassis /odomData /obstacle_list /qp_planning_result /qp_speed_result

## 回放
rosbag play xxx --topics /odomData