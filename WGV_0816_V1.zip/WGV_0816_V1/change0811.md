 # package.xml
 
 <build_depend>drifting_common</build_depend>
 
 <build_export_depend>drifting_common</build_export_depend>
 
 <exec_depend>drifting_common</exec_depend>
 
 # in find_package of CMakeLists.txt add:

drifting_common
 
 # main
 
 #include "drifting_common/INS.h"
