#!/bin/bash
# 初始化环境
source /opt/ros/noetic/setup.bash
source ./devel/setup.bash


function start_launches() {

    # 启动估计节点（NAV标签页）
    gnome-terminal --tab --title="NAV" -- bash -c " roslaunch show_planning_results_simple visualizer.launch; exec bash"
   
}
start_launches || {
    echo "启动失败！错误码: $?"
    pkill -f "roslaunch"  # 清理残留进程
}

