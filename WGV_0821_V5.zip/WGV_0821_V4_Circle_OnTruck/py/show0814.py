#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
live_plot_vt_safe.py  ——  线程安全的实时绘图
ROS1:  rosrun your_pkg live_plot_vt_safe.py
"""

import rospy
import numpy as np
import matplotlib
matplotlib.use('TkAgg')          # 显式指定后端，防止某些系统默认 Qt
import matplotlib.pyplot as plt

from collections import deque
from threading import Lock
from bit_planner_ros.msg import PlanningResult   # 换成你的消息

QUEUE_MAXLEN = 1                # 只保留最新一帧
class LiveVTPlot(object):
    def __init__(self):
        rospy.init_node('live_vt_plot_safe', anonymous=True)

        # 线程安全队列 + 锁
        self._queue = deque(maxlen=QUEUE_MAXLEN)
        self._lock = Lock()

        # matplotlib 初始化
        plt.ion()
        self.fig, self.ax = plt.subplots()
        self.ax.set_title('DP & QP velocity (v-t)')
        self.ax.set_xlabel('x [m]')
        self.ax.set_ylabel('v [m/s]')
        self.ax.grid(True)
        self.dp_line, = self.ax.plot([], [], 'k', label='DP')
        self.qp_line, = self.ax.plot([], [], 'g', label='QP')
        self.ax.legend()

        # 启动订阅（回调里只塞队列）
        rospy.Subscriber("/qp_speed_result", PlanningResult,
                         self._callback, queue_size=1)

       # 主线程轮询
        self._spin()

    # --------------------------------------------------
    def _callback(self, msg):
        """只把消息塞进线程安全队列，不做任何 UI 操作"""
        with self._lock:
            self._queue.append(msg)

    # --------------------------------------------------
    def _spin(self):
        rate = rospy.Rate(50)          # 50 Hz 刷新即可
        while not rospy.is_shutdown():
            with self._lock:
                if self._queue:
                    msg = self._queue.pop()
                else:
                    msg = None

            if msg is not None:
                self._update_plot(msg)

            rate.sleep()

    # --------------------------------------------------
    def _update_plot(self, msg):
        """真正刷新图形，始终在主线程执行"""
        x_dp = [p.t for p in msg.trajectory]
        v_dp = [p.v for p in msg.trajectory]

        # 如果 QP 结果在别的字段，这里改
        x_qp = x_dp
        v_qp = v_dp

        self.dp_line.set_data(x_dp, v_dp)
        self.qp_line.set_data(x_qp, v_qp)

        self.ax.relim()
        self.ax.set_ylim(0, 20)           # v 轴固定 0~5
        self.ax.autoscale_view()
        self.fig.canvas.draw()
        self.fig.canvas.flush_events()


# ------------------------------------------------------
if __name__ == '__main__':
    try:
        LiveVTPlot()
    except rospy.ROSInterruptException:
        pass