#include "EnvironmentPublisher.h"
#include <ros/ros.h>
#include <tuple>
#include <chrono>
#include<math.h>

using ObstacleInfo = std::tuple<double /*s*/, double /*l*/, double /*yaw_offset*/>;

int main(int argc, char** argv)
{
  ros::init(argc, argv, "environment_publisher");
  ros::NodeHandle nh;

  double obs_yaw =  0*M_PI/2.0;
  /* 初始障碍物列表 */
  std::vector<ObstacleInfo> my_obs = {
      {50.0, -3, obs_yaw},
      {120.0, 1, obs_yaw},
      {250.0, 0, obs_yaw}
      // {35.0, -13.0, M_PI/2.0},
      // {35.0, -17.9, M_PI/2.0},
      // {35.0, -22.8, M_PI/2.0},
      // {95.0, -1.0, 0.0},
      // {115.0, 1.0, 0.0}
  };

  /* 每条障碍的线速度（m/s） */
  std::vector<double> v_obs = {0, 0.0, 0.0}; //,0.0,0.0,0.0
  // std::vector<double> v_obs = {0.5,0.5,0.5,0.5};
  /* 构造发布器：主车起点 (10 m, 0 m) */
  EnvironmentPublisher env_pub(nh, my_obs, 0.0, 0.0);

  ros::Rate loop_rate(1);          // 10 Hz
  double t = 0.0;
  static bool added = false;
  while (ros::ok())
  {
    // if (t > 2.0 && !added) {
    //     my_obs.emplace_back(40.0, -2.0, 0.0);
    //     v_obs.push_back(2.0);

    //     added = true;          // 保证只加一次
    // }
    /* 实时更新障碍物位置：直线运动 s = s0 + v·t */
    if (1)
    {
      for (size_t i = 0; i < my_obs.size(); ++i)
      {
        std::get<0>(my_obs[i]) += v_obs[i]  * std::cos(obs_yaw);  // Δt = 0.1 s
        std::get<1>(my_obs[i]) += v_obs[i]  * std::sin(obs_yaw);
      }
    }

    env_pub.scenario_.updateObstacles(my_obs,v_obs);   // 重新生成障碍
    env_pub.publishReferenceLine();
    env_pub.publishObstacleList();
    // env_pub.publishLocalization();
    env_pub.publishOffset();

    ros::spinOnce();
    loop_rate.sleep();
    t += 0.1;
  }

  return 0;
}
