#ifndef SCE4_H_
#define SCE4_H_
#include "../common/cartesian_frenet_conversion.h"
#include "../common/discrete_points_math.h"
#include "../common/data_struct.h"
#include <cmath>
#include <vector>
#include <tuple>   // std::pair
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include <yaml-cpp/yaml.h>
#include <ros/package.h> 

struct RefConfig {
    std::string ref_path;
};

namespace {
RefConfig LoadRefConfig(const std::string& yaml_path) {
  RefConfig config;
  YAML::Node cfg = YAML::LoadFile(yaml_path);
  YAML::Node ref_cfg = cfg["ref_config"];

  config.ref_path = ref_cfg["path"].as<std::string>();
  return config;
}
}

class sce4 {
  public:

    float _yaw = 0.0;  // 初始定位航向角
    using ObstacleInfo = std::tuple<double, double, double>; // (s,l,yaw)

    /* 默认：3 个障碍物 + 主车起点(5,0) */
    sce4()
        : sce4({{50.0, 0.0, 0.0}, {110.0, -3.5, 0.0}, {68.0, 3.5, 0.0}}, 5.0, 0.0) {}

    /* 自定义：障碍物列表 + 主车起点(s,l) */
    explicit sce4(const std::vector<ObstacleInfo>& obs,
                  double ego_s, double ego_l)
        : obs_sl_list_(obs.empty()
                        ? std::vector<ObstacleInfo>{{50.0, 0.0, 0.0},
                                                    {110.0, -3.5, 0.0},
                                                    {68.0, 3.5, 0.0}}
                        : obs),
          ego_s_(ego_s),
          ego_l_(ego_l) {
        generateRoad(500.0);
    }

    ~sce4() = default;
  
    void generateRoad(double length) {
      const double radius   = 10.0;
      const double interval = 0.1;
      const int numPoints   = 315;
      const int numPoints1  = 843;
      const int numPoints2  = 842;
      const double deltaTheta = interval / radius;

      std::string pkg_path = ros::package::getPath("bit_planner_ros");
      std::string config_ref_path = pkg_path + "/config/ref_config.yaml";

      RefConfig config = LoadRefConfig(config_ref_path);

      // 0. 环线
      std::ifstream file(config.ref_path);
      //  std::ifstream file("/home/erhang/WGV_206/WGV_0823_OnTruck/ROSBAG/60_west.txt");
         if (!file.is_open()) {
          std::cerr << "Failed to open xy_trajectory.txt" << std::endl;
          return;
         }

          std::string line;
        std::getline(file, line); // 跳过表头

          while (std::getline(file, line)) {
               std::istringstream iss(line);
               double x_offset, y_offset;
              if (!(iss >> x_offset >> y_offset)) {
                 continue; // 跳过无效行
              }

               TrajectoryPoint temp;
               temp.xg = x_offset;          // 直接读取偏移量作为全局坐标
               temp.yg = y_offset;
               temp.global_angle = 0;       // 可后续计算
               temp.length = 0.2;             // 可后续累加
               centerlane_.push_back(temp);
           }

           file.close();

           // 可选：计算累计路径长度和航向角
           for (size_t i = 1; i < centerlane_.size(); ++i) {
               double dx = centerlane_[i].xg - centerlane_[i - 1].xg;
               double dy = centerlane_[i].yg - centerlane_[i - 1].yg;
               centerlane_[i].length = std::hypot(dx, dy);
               centerlane_[i].global_angle = 0;
           }
     
      // // 1. 直线
      // TrajectoryPoint temp;
       //for (double i = 0; i < length; i += 0.1) {
       //  TrajectoryPoint temp;
        // temp.xg = i*cos(_yaw);  //i
        // temp.yg = i*sin(_yaw); // 0
        // temp.length = i;
        // temp.global_angle = 0;
        // centerlane_.push_back(temp);
    // }

      // // 2. 环线
      // TrajectoryPoint temp;
      // double horizon_length = 180;
      // double vertical_length = 80;
      // double radius_length = 40;
      // double radius_delta = 0.2;
      // for (double i = 0; i < horizon_length; i += 0.2) {
      //   TrajectoryPoint temp;
      //   temp.xg = i*cos(_yaw);  //i
      //   temp.yg = i*sin(_yaw); // 0
      //   temp.length = i;
      //   centerlane_.push_back(temp);
      // }
      // for (double i = 0; i < M_PI*radius_length; i += radius_delta) {
      //   TrajectoryPoint temp;
      //   double theta = -M_PI/2 + i/radius_length;
      //   temp.xg = horizon_length*cos(_yaw)+radius_length*cos(theta) ;  //i
      //   temp.yg = horizon_length*sin(_yaw)+radius_length*sin(theta)+radius_length; // 0
      //   temp.length = radius_delta ;
      //   centerlane_.push_back(temp);
      // }
     
      // for (double i = 0; i < horizon_length; i += 0.2) {
      //   TrajectoryPoint temp;
      //   temp.xg = i*cos(_yaw+M_PI) + horizon_length;  //i
      //   temp.yg = i*sin(_yaw+M_PI) + 2*radius_length; // 0
      //   temp.length = i;
      //   centerlane_.push_back(temp);
      // }
      // for (double i = 0; i < M_PI*radius_length; i += radius_delta) {
      //   TrajectoryPoint temp;
      //   double theta = M_PI/2 + i/radius_length;
      //   temp.xg = radius_length*cos(theta) ;  //i
      //   temp.yg = radius_length*sin(theta)+radius_length; // 0
      //   temp.length = radius_delta ;
      //   centerlane_.push_back(temp);
      // }
     

      // TrajectoryPoint temp;
      // double horizon_length = 200;
      // double vertical_length = 80;
      // for (double i = 0; i < horizon_length; i += 0.1) {
      //   TrajectoryPoint temp;
      //   temp.xg = i*cos(_yaw);  //i
      //   temp.yg = i*sin(_yaw); // 0
      //   temp.length = i;
      //   centerlane_.push_back(temp);
      // }
      // for (double i = 0; i < vertical_length; i += 0.1) {
      //   TrajectoryPoint temp;
      //   temp.xg = i*cos(_yaw-1.5708)+horizon_length*cos(_yaw) ;  //i
      //   temp.yg = i*sin(_yaw-1.5708)+horizon_length*sin(_yaw); // 0
      //   temp.length = i+horizon_length;
      //   centerlane_.push_back(temp);
      // }
      // for (double i = 0; i < horizon_length; i += 0.1) {
      //   TrajectoryPoint temp;
      //   temp.xg = i*cos(_yaw-1.5708*2)+horizon_length*cos(_yaw)+vertical_length*cos(_yaw-1.5708);  //i
      //   temp.yg = i*sin(_yaw-1.5708*2)+horizon_length*sin(_yaw)+vertical_length*sin(_yaw-1.5708); // 0
      //   temp.length = i+horizon_length+vertical_length;
      //   centerlane_.push_back(temp);
      // }
      // for (double i = 0; i < vertical_length; i += 0.1) {
      //   TrajectoryPoint temp;
      //   temp.xg = i*cos(_yaw-1.5708)+horizon_length*cos(_yaw)+vertical_length*cos(_yaw-1.5708)+horizon_length*cos(_yaw-2*1.5708);  //i
      //   temp.yg = i*sin(_yaw-1.5708)+horizon_length*sin(_yaw)+vertical_length*sin(_yaw-1.5708)+horizon_length*sin(_yaw-2*1.5708); // 0
      //   temp.length = i+2*horizon_length+vertical_length;
      //   centerlane_.push_back(temp);
      // }
        // 1.生成S弯参考线

      // const double radius = 25.0;   // 圆的半径（单位：m）
      // const double interval = 0.1;  // 采样间隔（单位：m）
      // const int numPoints = 1200;    // 计算大约需要的点数
      // const int numPoints1 = 1600;
      // const int numPoints2 = 3600;
      // const int numPoints3 = 4000;
      // const int numPoints4 = 3600;
      // const double deltaTheta = interval / radius;
      // double theta = 0.0;
      // TrajectoryPoint temp;
      // for (std::size_t i = 0; i < numPoints1; ++i) {
      //   temp.xg = i * interval - 84.3;
      //   temp.yg = radius;
      //   temp.length = i * 0.1;
      //   centerlane_.push_back(temp);
      // }

      // for (std::size_t i = 0; i < numPoints; ++i) {
      //   theta = i * deltaTheta;
      //   temp.xg = -radius * std::cos(theta + 1.5708);
      //   temp.yg = radius * std::sin(theta + 1.5708);
      //   temp.length = i * 0.1 + 0.1 * numPoints1;
      //   centerlane_.push_back(temp);
      // }
      // for (std::size_t i = 0; i < numPoints2; ++i) {
      //   temp.xg = i * -0.1;
      //   temp.yg = -radius;
      //   temp.length = i * 0.1 + 0.1 * (numPoints + numPoints1);
      //   centerlane_.push_back(temp);
      // }



      ComputePathProfile(centerlane_);

      // 2. 生成车道线/边界 Frenet 坐标
      size_t n = centerlane_.size();
      leftRoadBound_.resize(n);
      rightRoadBound_.resize(n);
      leftDashed_.resize(n);
      rightDashed_.resize(n);
      leftLane_.resize(n);
      rightLane_.resize(n);

      for (size_t i = 0; i < n; ++i) {
        double s = i * 0.1;

        auto setFrenet = [s](TrajectoryPoint& p, double l) {
          p.frenet_info.s = s;
          p.frenet_info.l = l;
        };

        setFrenet(leftRoadBound_[i],  5.25);
        setFrenet(rightRoadBound_[i], -5.25);
        setFrenet(leftDashed_[i],     1.75);
        setFrenet(rightDashed_[i],   -1.75);
        setFrenet(leftLane_[i],       3.5);
        setFrenet(rightLane_[i],     -3.5);
      }

      // Frenet -> Cartesian
      FrenetToCartesian(leftRoadBound_,  centerlane_);
      FrenetToCartesian(rightRoadBound_, centerlane_);
      FrenetToCartesian(leftDashed_,     centerlane_);
      FrenetToCartesian(rightDashed_,    centerlane_);
      FrenetToCartesian(leftLane_,       centerlane_);
      FrenetToCartesian(rightLane_,      centerlane_);

      // 3. 生成障碍物
      obs_.obstacle_list.clear();
      Obstacle obs;
      obs.length = 0.0;
      obs.width  = 0.0;
      obs.traj_p.v = 0.0;
      obs.traj_p.a = 0.0;

      for (const auto& info : obs_sl_list_) {
      double s   = std::get<0>(info);
      double l   = std::get<1>(info);
      double yaw_offset = std::get<2>(info);

      TrajectoryPoint proj = FindFrenetProjPoint(centerlane_, s);
      FrenetToCartesian(proj.length, proj.xg, proj.yg,
                        proj.global_angle, s, l,
                        obs.traj_p.xg, obs.traj_p.yg);

      obs.traj_p.global_angle = proj.global_angle + yaw_offset; // 完全自定义
      obs_.obstacle_list.push_back(obs);
      }

      // 4. 主车初始定位
      TrajectoryPoint ego_proj = FindFrenetProjPoint(centerlane_, ego_s_);
      FrenetToCartesian(ego_proj.length, ego_proj.xg, ego_proj.yg,
                        ego_proj.global_angle, ego_s_, ego_l_,
                        ego_loc_.xg, ego_loc_.yg);
      ego_status_.v = ego_v_;   // 无速度
      ego_status_.a = 0.0;


      // 5. 主车参考线
      referenceLine_ = centerlane_;
    } 
    void updateObstacles(const std::vector<ObstacleInfo>& new_obs, const std::vector<double>& v_obs) {
      obs_sl_list_= new_obs ;          // 1. 快速替换
      obs_.obstacle_list.clear();      // 2. 清空旧障碍

      Obstacle obs;
      obs.length = 4.8;
      obs.width  = 2.4;
      
      obs.traj_p.a = 0.0;

      for (size_t i = 0; i < obs_sl_list_.size(); ++i) {
          double s   = std::get<0>(obs_sl_list_[i]);
          double l   = std::get<1>(obs_sl_list_[i]);
          double yaw = std::get<2>(obs_sl_list_[i]);
      
          TrajectoryPoint proj = FindFrenetProjPoint(centerlane_, s);
          double x, y;
          FrenetToCartesian(proj.length, proj.xg, proj.yg,
                            proj.global_angle, s, l, x, y);
          obs.traj_p.xg = x;
          obs.traj_p.yg = y;
          obs.traj_p.v  = v_obs[i];  
          obs.traj_p.global_angle = proj.global_angle + yaw;
          obs_.obstacle_list.push_back(obs);
      }
    }

 public:
  // 全局参考线及道路边界
  std::vector<TrajectoryPoint> referenceLine_;
  std::vector<TrajectoryPoint> leftRoadBound_;
  std::vector<TrajectoryPoint> rightRoadBound_;
  std::vector<TrajectoryPoint> leftDashed_;
  std::vector<TrajectoryPoint> rightDashed_;
  std::vector<TrajectoryPoint> centerlane_;
  std::vector<TrajectoryPoint> leftLane_;
  std::vector<TrajectoryPoint> rightLane_;

  ObstacleList obs_;          // 障碍物列表
  Localization ego_loc_;      // 主车定位
  VehicleStatus ego_status_;  // 主车状态



private:
  std::vector<ObstacleInfo> obs_sl_list_;
  double ego_s_, ego_l_;   // 主车初始 (s,l)
  double ego_v_ = 20;
};

#endif  // sce4_H_
