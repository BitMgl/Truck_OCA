#include "../include/em_planner.h"
#include <yaml-cpp/yaml.h>
#include <ros/package.h>
#include <iostream>

namespace {
DpPathConfig LoadDpPathConfig(const std::string& yaml_path) {
  DpPathConfig config;
  YAML::Node cfg = YAML::LoadFile(yaml_path);
  YAML::Node dp_cfg = cfg["dp_config"];

  config.w_cost_obs = dp_cfg["w_cost_obs"].as<double>();
  config.w_cost_dl = dp_cfg["w_cost_dl"].as<double>();
  config.w_cost_ddl = dp_cfg["w_cost_ddl"].as<double>();
  config.w_cost_dddl = dp_cfg["w_cost_dddl"].as<double>();
  config.w_cost_ref = dp_cfg["w_cost_ref"].as<double>();
  config.rows = dp_cfg["rows"].as<int>();
  config.cols = dp_cfg["cols"].as<int>();
  config.sample_s = dp_cfg["sample_s"].as<double>();
  config.sample_l = dp_cfg["sample_l"].as<double>();
  config.ds = dp_cfg["ds"].as<double>();
  return config;
}

DpSpeedConfig LoadDpSpeedConfig(const std::string& yaml_path) {
  DpSpeedConfig config;
  YAML::Node cfg = YAML::LoadFile(yaml_path);
  auto node = cfg["dp_speed_config"];

  config.rows = node["rows"].as<int>();
  config.cols = node["cols"].as<int>();
  config.ref_v = node["ref_v"].as<double>();
  config.w_cost_obs = node["w_cost_obs"].as<double>();
  config.w_cost_ref_v = node["w_cost_ref_v"].as<double>();
  config.w_cost_a = node["w_cost_a"].as<double>();
  config.dt = node["dt"].as<double>();

  return config;
}

}

void EMPlanner::mergeTrajectory(std::vector<TrajectoryPoint>& lat_path,
                                std::vector<TrajectoryPoint>& lon_path) {
  int last_index = 0;
  for (auto& point : lon_path) {
    if (last_index > 0) last_index -= 1;
    for (; last_index < lat_path.size() - 1; last_index++) {
      // std::cout << "lon s: " << point.frenet_info.s
      //           << " lat s: " << lat_path[last_index].frenet_info.s
      //           << std::endl;
      if (point.frenet_info.s + 1e-5 >= lat_path[last_index].frenet_info.s &&
          point.frenet_info.s < lat_path[last_index + 1].frenet_info.s) {
        double proportion =
            (point.frenet_info.s - lat_path[last_index].frenet_info.s) /
            (lat_path[last_index + 1].frenet_info.s -
             lat_path[last_index].frenet_info.s);
        point.xg = lat_path[last_index].xg +
                   proportion *
                       (lat_path[last_index + 1].xg - lat_path[last_index].xg);
        point.yg = lat_path[last_index].yg +
                   proportion *
                       (lat_path[last_index + 1].yg - lat_path[last_index].yg);
        // std::cout << "lat xg: " << lat_path[last_index].xg
        //           << " lat yg: " << lat_path[last_index + 1].yg << std::endl;
        break;
      }
    }
  }
}

void EMPlanner::Plan() {
  // 获取配置文件路径
  std::string pkg_path = ros::package::getPath("em_planner_ros");
  std::string config_path = pkg_path + "/config/dp_config.yaml";

  // step1: sl dp
  DpPathConfig dp_config = LoadDpPathConfig(config_path);

  std::vector<TrajectoryPoint> obs_list;
  for (auto& obs : obs_) {
    obs_list.push_back(obs.traj_p);
  }
  dp_path_alg_.frenetDpPath(obs_list, obs_, start_point_, dp_config, dp_path_);
  dp_path_alg_.trajectoryInterp(dp_path_, dp_config);
  FrenetToCartesian(dp_path_, referenceLine_);
  dp_path_alg_.getCovexBound(dp_path_, start_point_, obs_list, obs_, dp_config);

  // step2: sl qp
  PiecewiseJerkPathProblem sl_qp(
      dp_path_alg_.ub_, dp_path_alg_.lb_, dp_config.ds,
      {start_point_.frenet_info.l, start_point_.frenet_info.l_ds,
       start_point_.frenet_info.l_dds});
  qp_path_ = dp_path_;
  bool qp_success = sl_qp.Optimize(qp_path_);
  FrenetToCartesian(qp_path_, referenceLine_);
  bool flag_qp = ComputePathProfile(qp_path_);

  // step3: st dp
  DpSpeed dp_speed;
  // DpSpeedConfig dp_speed_config;
  // dp_speed_config.rows = 100;
  // dp_speed_config.cols = 8;
  // dp_speed_config.ref_v = 20;
  // dp_speed_config.w_cost_obs = 10;
  // dp_speed_config.w_cost_ref_v = 10;
  // dp_speed_config.w_cost_a = 50;
  // dp_speed_config.dt = 0.1;

  // step3: st dp
  std::string speed_config_path = pkg_path + "/config/dp_speed_config.yaml";
  DpSpeedConfig dp_speed_config = LoadDpSpeedConfig(speed_config_path);

  dp_speed_alg_.s_max_ = qp_path_.back().frenet_info.s;
  dp_speed_alg_.getObsStByCartesian(obs_, qp_path_);
  dp_speed_alg_.frenetDpSpeed(start_point_, dp_speed_config, dp_speed_);
  dp_speed_alg_.trajectoryInterp(dp_speed_, dp_speed_config);
  dp_speed_alg_.getCovexBound(dp_speed_);

  // step4: st qp
  PiecewiseJerkSpeedProblem st_qp(dp_speed_alg_.ub_, dp_speed_alg_.lb_, 0.1,
                                  {0, 0, 0});
  qp_speed_ = dp_speed_;
  st_qp.Optimize(qp_speed_);

  // step5: merge trajectory
  st_path_ = qp_speed_;
  mergeTrajectory(qp_path_, st_path_);
}