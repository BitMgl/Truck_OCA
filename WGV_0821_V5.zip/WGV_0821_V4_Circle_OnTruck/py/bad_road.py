#!/usr/bin/env python
import rospy
import math
import numpy as np
from drifting_common.msg import INS

class FakeINSPublisher:
    def __init__(self):
        rospy.init_node('fake_ins_publisher', anonymous=True)
        
        
        self.mode = rospy.get_param("~mode", "constant")  
        self.publish_rate = rospy.get_param("~rate", 50)  
        self.constant_vx = rospy.get_param("~constant_vx", 0.5)  
        self.sinusoidal_amp = rospy.get_param("~amplitude", 1.0) 
        self.sinusoidal_freq = rospy.get_param("~frequency", 0.5)  
        self.path_file = rospy.get_param("~path_file", "") 

        
        self.start_time = rospy.Time.now()
        self.path_data = None
        if self.mode == "path" and self.path_file:
            self.path_data = self._load_path()
        
        self.ins_pub = rospy.Publisher("/drifting/ins", INS, queue_size=10)
        
        
        rospy.Timer(rospy.Duration(1.0/self.publish_rate), self.timer_callback)

    def _load_path(self):
        
        try:
            data = np.genfromtxt(self.path_file, delimiter=',', names=True)
            return data
        except Exception as e:
            
            return None

    def timer_callback(self, event):
        
        current_time = (rospy.Time.now() - self.start_time).to_sec()
        ins_msg = INS()
        
       
        if self.mode == "constant":
          
            ins_msg.INS_vx = self.constant_vx
            ins_msg.INS_vy = 0.0
            ins_msg.INS_NorthSpd = self.constant_vx  
            ins_msg.INS_EastSpd = 0.0
            ins_msg.INS_ToGroundSpd = 0.0
            ins_msg.INS_X = 0.41 #441557.0 #0.41        
            ins_msg.INS_Y = 1.2# 4423324.0 #1.2
            ins_msg.INS_HeadingAngle = 0.5
            
        elif self.mode == "sinusoidal":
           
            omega = 2 * math.pi * self.sinusoidal_freq
            ins_msg.INS_vx = self.constant_vx
            ins_msg.INS_vy = self.sinusoidal_amp * math.sin(omega * current_time)
            
            ins_msg.INS_NorthSpd = ins_msg.INS_vx
            ins_msg.INS_EastSpd = ins_msg.INS_vy
            
        elif self.mode == "path" and self.path_data is not None:
            
            idx = np.searchsorted(self.path_data['time'], current_time, side='left')
            if idx >= len(self.path_data):
                idx = len(self.path_data) - 1
                
            ins_msg.INS_vx = self.path_data['vx'][idx]
            ins_msg.INS_vy = self.path_data['vy'][idx]
            ins_msg.INS_NorthSpd = self.path_data['x'][idx]  
            ins_msg.INS_EastSpd = self.path_data['y'][idx]   
            
        else:
            rospy.logwarn("Invalid mode or path data!")
            return
        
        self.ins_pub.publish(ins_msg)

if __name__ == '__main__':
    try:
        publisher = FakeINSPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
