#pragma once

#include <utility>

#include "data_struct.h"

bool ComputePathProfile(std::vector<TrajectoryPoint>& raw_cartesian_path);
